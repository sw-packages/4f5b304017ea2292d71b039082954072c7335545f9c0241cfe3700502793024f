// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR BSD-3-Clause

//! [0]
./myapplication -style windows
//! [0]


//! [1]
./myapplication -style custom
//! [1]
